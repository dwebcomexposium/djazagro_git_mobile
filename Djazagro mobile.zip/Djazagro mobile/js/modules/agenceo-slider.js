/**!
 Agence'O Slider
 Slider scripts

 @contributors: Guillaume Bouillon (Agence'O)
 @date-created: 2016-07-12
 @last-update: 2016-07-12
 */

;(function ($) {
    
    // delete class cxp-swiper for mobile device
    $('.cxp-swiper').removeClass('cxp-swiper').addClass('ao-slider');

    // Reads plugin settings from HTML data-* attributes (camelCase)
    var slider_config = $('.la-slider').data();
    var config_default = {
        loop: true,
        itemsPerSlide: 1,
        paginateByBullet: true,
        autoDelay: 2500,
        speed: 2500
    };
    var config = $.extend(config_default, slider_config);

    // init sliders mobile
    $('.la-slider .slider-content').slick({
        infinite: config.loop,
        arrows: false,
        slidesToShow: config.itemsPerSlide,
        slidesToScroll: config.itemsPerSlide,
        dots: config.paginateByBullet,
        swipeToSlide: true,
        autoplay: (config.autoDelay) ? true : false,
        autoplaySpeed: config.autoDelay,
        speed: config.speed
    });

})(jQuery);
