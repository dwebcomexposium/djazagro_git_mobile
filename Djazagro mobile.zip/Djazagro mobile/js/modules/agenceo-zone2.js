/**!
 Agence'O Scripts - Zone2
 Change blocks positions in #zone2

 @contributors: Agence'O
 @date-created: 2016-06-28
 @date-updated: 2016-07-18
 */

;(function ($) {

    $('.article-wrapper .article-title .inside img').appendTo('.article-wrapper .article-intro');
    //$('.front #zone1 .edito.event').after($('.front #zone1 .quicklinks'));

})(jQuery);