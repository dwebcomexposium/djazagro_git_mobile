/**!
 Agence'O Article
 Article scripts

 @contributors: Guillaume Bouillon (Agence'O)
 @date-created: 2016-07-12
 @last-update: 2016-07-12
 */

;(function ($) {

    var $at_block = $('.block.article-title')
    var $at_illust = $at_block.find('.at-illust');
    var $at_title = $at_block.find('.at-main-title').after($at_illust);
    
})(jQuery);
